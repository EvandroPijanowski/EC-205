
package sellcar;

public class Funcionario 
{
    private String nome, rg, cpf, salario;
    private int cargo;
    private float bonus;
    
    
    public String getNome(){return nome;}
    public String getCpf() {return cpf;};
    public String getRg() {return rg;};
    public String getSalario() {return salario;};
    public int getCargo() {return cargo;};
    
    public void setNome(String nome){this.nome =  nome;};
    public void setCpf(String cpf) {this.cpf = cpf;};
    public void setRg(String rg) {this.rg = rg;};
    public void setSalario(String salario) {this.salario = salario;};
    public void setCargo(int cargo){this.cargo =  cargo;};
        
    
}
