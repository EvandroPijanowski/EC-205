package sellcar;

import java.util.regex.Pattern;
import javax.swing.JOptionPane;

public class Validacao 
{

    public static boolean isValidNome(String nome) 
    {
        if (nome.length() == 0 || nome.length() > 50 || hasDigits(nome)) 
        {
            return false;
        }
        return !hasSpecialCharacters(nome);
    }

    public static boolean isValidCpf(String cpf) 
    {
        if (cpf.length() != 11) 
        {
            return false;
        }
        return (!hasLetters(cpf) && !hasSpecialCharacters(cpf));
    }

    //verificar se começa com letra
    public static boolean isValidRg(String rg) 
    {
        if (rg.length() > 14) 
        {
            return false;
        }
        return (!hasLetters(rg) && !hasSpecialCharacters(rg));
    }

    public static boolean isSalario(String salario) 
    {
        Pattern regex = Pattern.compile("[@]");
        return (!hasLetters(salario) && !hasSpecialCharacters(salario));
    }

    private static boolean hasLetters(String s) 
    {
        Pattern regex = Pattern.compile("[a-zA-Z]");
        return regex.matcher(s).find();
    }

    private static boolean hasSpecialCharacters(String s) 
    {
        Pattern regex = Pattern.compile("[$&+,:;=?@#|]");
        return regex.matcher(s).find();
    }

    private static boolean hasDigits(String s) 
    {
        Pattern regex = Pattern.compile("[0-9]");
        return regex.matcher(s).find();
    }

}
