

package sellcar;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import org.omg.CORBA.portable.OutputStream;


public class Armazenamento 
{
    public void salvaFuncionario(String nome, String cpf, String rg, String salario, int cargo) throws IOException
    {
        FileOutputStream os = new FileOutputStream("funcionario.txt", true);
        OutputStreamWriter osw = new OutputStreamWriter(os);
        BufferedWriter bw = new BufferedWriter(osw);

        bw.write(nome + "-" + cpf + "-" + rg + "-" + salario + "-" + cargo + ".");
        bw.newLine();
        bw.close();
    }
    
    void salvarVeiculo() throws FileNotFoundException, IOException
    {
        FileOutputStream os = new FileOutputStream("funcionario.txt", true);
        OutputStreamWriter osw = new OutputStreamWriter(os);
        BufferedWriter bw = new BufferedWriter(osw);

        bw.write("");
        bw.newLine();
        bw.close();
    }
    
}
