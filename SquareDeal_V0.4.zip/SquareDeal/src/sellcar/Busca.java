
package sellcar;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Busca 
{
    public ArrayList<String> busca(String search) throws FileNotFoundException, IOException
    {
        InputStream is = new FileInputStream("funcionario.txt");
        InputStreamReader isr = new InputStreamReader(is);
        BufferedReader br = new BufferedReader(isr);
        String line = null;
        int find = 0;
        ArrayList<String> results = new ArrayList<>();
        
        while((line = br.readLine()) != null){
            if(line.contains(search)){
                results.add(line);
                find = 1;
                
            }
        }
        if(find == 1) return results;
        else return null;
        
    }
}
