
package br.com.inatel.sellcar.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import static java.lang.Math.abs;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import sellcar.Busca;


public class Vender extends javax.swing.JFrame
{
    private DefaultListModel lista = new DefaultListModel();
    String[] aux;
    
    public Vender() 
    {
        initComponents();
        buscarButton.addActionListener(new Action());
        setVisible(true);
        valorEntregueTextField.setText("0");
        /*int index = jList1.getSelectedIndex();
            if (index != -1) 
            {
                precoTextField.setText(jList1.getSelectedValue().toString());
            }*/
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        buscarButton = new javax.swing.JButton();
        buscarTextField = new javax.swing.JTextField();
        venderLabel = new javax.swing.JLabel();
        buscarLabel = new javax.swing.JLabel();
        precoLabel = new javax.swing.JLabel();
        trocoLabel = new javax.swing.JLabel();
        concluirButton = new javax.swing.JButton();
        selecionarButton = new javax.swing.JButton();
        valorLabel = new javax.swing.JLabel();
        valorEntregueLabel = new javax.swing.JLabel();
        valorEntregueTextField = new javax.swing.JTextField();
        valorTrocoLabel = new javax.swing.JLabel();
        confirmarButton = new javax.swing.JButton();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setPreferredSize(new java.awt.Dimension(850, 593));

        jList1.setModel(lista);
        jList1.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane1.setViewportView(jList1);
        jScrollPane1.setViewportView(jList1);

        buscarButton.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        buscarButton.setText("Buscar");

        buscarTextField.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        venderLabel.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        venderLabel.setText("Vender");

        buscarLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        buscarLabel.setText("Buscar:");

        precoLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        precoLabel.setText("Preço:");

        trocoLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        trocoLabel.setText("Troco:");

        concluirButton.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        concluirButton.setText("Concluir");
        concluirButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                concluirButtonActionPerformed(evt);
            }
        });

        selecionarButton.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        selecionarButton.setText("Selecionar");
        selecionarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selecionarButtonActionPerformed(evt);
            }
        });

        valorEntregueLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        valorEntregueLabel.setText("Valor entregue:");

        valorEntregueTextField.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        valorTrocoLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        confirmarButton.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        confirmarButton.setText("Confirmar");
        confirmarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmarButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(venderLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(buscarLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(trocoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(31, 31, 31)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 433, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(selecionarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(buscarTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(buscarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(valorTrocoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(432, 432, 432))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(confirmarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(150, 150, 150)
                        .addComponent(concluirButton, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(precoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(valorLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(valorEntregueLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(valorEntregueTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(148, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(venderLabel)
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(buscarLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buscarTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buscarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addComponent(selecionarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(precoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(valorLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(valorEntregueLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(valorEntregueTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE))
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(trocoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(valorTrocoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(61, 61, 61)
                        .addComponent(concluirButton, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(confirmarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(53, 53, 53))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void selecionarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selecionarButtonActionPerformed
        // TODO add your handling code here:
        if(jList1.isSelectionEmpty())
        {
            valorLabel.setText("R$ 0.00");
        }
        else
        {
            valorLabel.setText("R$ " + aux[10] + ",00");
        }
        valorEntregueTextField.setText("0");
    }//GEN-LAST:event_selecionarButtonActionPerformed

    private void confirmarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmarButtonActionPerformed
        // TODO add your handling code here:
        if((valorLabel.getText() == "R$ 0.00") || (valorEntregueTextField.getText() == "0"))
        {
            valorTrocoLabel.setText("R$ 0.00");
        }
        else
        {
            int valor = Integer.parseInt(aux[10]);
            int entregue = Integer.parseInt(valorEntregueTextField.getText());
            int troco = valor - entregue;
            
            if(valor > entregue)
            {
                valorTrocoLabel.setText("Quantia Insuficiente!!!");
            }
            else
            {
                valorTrocoLabel.setText("R$ " + abs(troco));
            }
        }
        
    }//GEN-LAST:event_confirmarButtonActionPerformed

    private void concluirButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_concluirButtonActionPerformed
        // TODO add your handling code here:
        if(valorLabel.getText() == "R$ 0.00")
            JOptionPane.showMessageDialog(null, "Nenhum veículo foi selecionado!","Veículo não selecionado", JOptionPane.ERROR_MESSAGE);
        
        else
        {
            if(valorTrocoLabel.getText() == "Quantia Insuficiente!!!")
                JOptionPane.showMessageDialog(null, "A quantia entregue pelo cliente é menor do que o valor do automóvel. Avise-o!!!","Quantia insuficiente", JOptionPane.ERROR_MESSAGE);
            
            else
            {
                System.out.println("FAZER DEPOIS");
                
            }
        }
    }//GEN-LAST:event_concluirButtonActionPerformed

    
    public static void main(String args[]) 
    {
        
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            public void run() 
            {
                new Vender().setVisible(true);
            }
        });
    }
    
    boolean buscaFunc;
    ArrayList<String> resultado;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buscarButton;
    private javax.swing.JLabel buscarLabel;
    private javax.swing.JTextField buscarTextField;
    private javax.swing.JButton concluirButton;
    private javax.swing.JButton confirmarButton;
    private javax.swing.JList<String> jList1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel precoLabel;
    private javax.swing.JButton selecionarButton;
    private javax.swing.JLabel trocoLabel;
    private javax.swing.JLabel valorEntregueLabel;
    private javax.swing.JTextField valorEntregueTextField;
    private javax.swing.JLabel valorLabel;
    private javax.swing.JLabel valorTrocoLabel;
    private javax.swing.JLabel venderLabel;
    // End of variables declaration//GEN-END:variables

    class Action implements ActionListener
    {  //Action
        
        public void actionPerformed(ActionEvent e) 
        {
            
            String search = buscarTextField.getText();    //salva o que digitou em uma variavel

            Busca b = new Busca();
            buscarTextField.setText("");
            lista.clear();

            try 
            {
                resultado = b.busca(search, false);
            } catch (IOException ex) 
            {
                Logger.getLogger(Buscar.class.getName()).log(Level.SEVERE, null, ex);
            }
            if (resultado == null) 
            {
                JOptionPane.showMessageDialog(null, "Veiculo não encontrado", "Erro", JOptionPane.ERROR_MESSAGE);
            } 
            else 
            {
                
                for (int i = 0; i < resultado.size(); i++) 
                {
                    aux = resultado.get(i).split("-");
                    lista.addElement("Modelo: " + aux[0] + " Marca: " + aux[1] + " Versâo: "
                            + aux[2] + " Cor: " + aux[3] + "\nMotor: " + aux[4] + " Quilometragem: " + aux[5]
                            + " Ano Modelo: " + aux[6] + " Ano Fabricação: " + aux[7] + "\n Especie: " + aux[8]
                            + " Chassi: " + aux[9] + " Valor: " + aux[10] + "\n\n");
                }
                
            }
        }
    }
    
   
}
