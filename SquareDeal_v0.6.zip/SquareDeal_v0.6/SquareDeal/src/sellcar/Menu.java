
package sellcar;


public class Menu 
{
    int opcao = 0;
    
    public void mostrar()
    {
        System.out.println("/t/tMenu");
        System.out.println("1- Cadastrar /n");
        System.out.println("2- Editar /n");
        System.out.println("3- Buscar /n");
        System.out.println("4- Vender /n");
    }
    
    
}
