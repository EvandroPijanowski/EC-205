
package sellcar;

import br.com.inatel.sellcar.view.*;

/**
 *
 * @author C I C E R O
 */
public class SellCar 
{

    
    public static void main(String[] args) 
    {
        Login l = new Login();
    }
}
