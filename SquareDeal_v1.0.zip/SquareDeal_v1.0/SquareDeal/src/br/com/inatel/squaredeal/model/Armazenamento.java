package br.com.inatel.squaredeal.model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import org.omg.CORBA.portable.OutputStream;

public class Armazenamento {

    public void copiaOriginal(String lastid) throws FileNotFoundException, IOException {
        InputStream is = new FileInputStream("veiculos.txt");
        InputStreamReader isr = new InputStreamReader(is);
        BufferedReader br = new BufferedReader(isr);
        String s = br.readLine();
        String lastvid = "Last ID:";

        FileWriter arquivo;

        arquivo = new FileWriter(new File("Arquivo.txt"));
        while (!lastvid.concat(lastid).equals(s)) {
            arquivo.write(s + "\r\n");
            s = br.readLine();
        }
        arquivo.close();
    }

    public void copiaAuxiliar(Veiculo v, int id) throws FileNotFoundException, IOException {
        InputStream is = new FileInputStream("Arquivo.txt");
        InputStreamReader isr = new InputStreamReader(is);
        BufferedReader br = new BufferedReader(isr);
        String s = br.readLine();

        FileWriter arquivo;

        arquivo = new FileWriter(new File("veiculos.txt"));
        while (s != null) {
            arquivo.write(s + "\r\n");
            s = br.readLine();
        }
        arquivo.write(v.getModelo() + "-" + v.getMarca() + "-" + v.getVersao() + "-" + v.getCor()
                + "-" + v.getMotor() + "-" + v.getQuilometragem() + "-" + v.getAnoModelo() + "-"
                + v.getAnoFabricacao() + "-" + v.getEspecie() + "-" + v.getChassi() + "-" + v.getValor() + "-" + id + ";");
        arquivo.write("\r\n" + "Last ID:".concat(Integer.toString(id)));
        arquivo.close();
    }

    public String cutString(String palavra) {
        String[] nulos = {"Last ID:"};
        for (String n : nulos) {
            palavra = palavra.replaceAll(n, "");
        }
        return palavra;
    }

    public String getLastID() throws FileNotFoundException, IOException {
        InputStream is = new FileInputStream("veiculos.txt");
        InputStreamReader isr = new InputStreamReader(is);
        BufferedReader br = new BufferedReader(isr);
        String line = null, lastid = null;

        while ((line = br.readLine()) != null) {
            if (line.contains("Last ID:")) {
                lastid = line;
            }
        }
        if (lastid == null) {
            JOptionPane.showMessageDialog(null, "Ultimo ID não encontrado, complete manualmente o arquivo.", "Erro", JOptionPane.ERROR_MESSAGE);
        }

        return lastid;
    }

    public void salvaFuncionario(String nome, String cpf, String rg, String salario, int cargo) throws IOException {
        FileOutputStream os = new FileOutputStream("funcionario.txt", true);
        OutputStreamWriter osw = new OutputStreamWriter(os);
        BufferedWriter bw = new BufferedWriter(osw);

        bw.write(nome + "-" + cpf + "-" + rg + "-" + salario + "-" + cargo);
        bw.newLine();
        bw.close();
    }

    public void salvarVeiculo(Veiculo v) throws FileNotFoundException, IOException {
        String lastvid;
        int newvid;

        lastvid = getLastID();
        lastvid = cutString(lastvid);
        System.out.println(lastvid);
        newvid = Integer.parseInt(lastvid.trim()) + 1;

        copiaOriginal(lastvid);
        copiaAuxiliar(v, newvid);
    }

    public void salvarUser(String user, String pass, int cargo) throws IOException {
        int senha;
        FileOutputStream os = new FileOutputStream("users.txt", true);
        OutputStreamWriter osw = new OutputStreamWriter(os);
        BufferedWriter bw = new BufferedWriter(osw);

        System.out.println("senha salva: ");

        bw.write(user + "-" + pass + "-" + cargo);
        bw.newLine();
        bw.close();
    }

    public void venderVeiculo(int id) throws IOException {
        InputStream is = new FileInputStream("veiculos.txt");
        InputStreamReader isr = new InputStreamReader(is);
        BufferedReader br = new BufferedReader(isr);
        String s = br.readLine();

        FileWriter arquivo;

        arquivo = new FileWriter(new File("Arquivo.txt"));
        while (s != null) {
            if (s.contains("-" + Integer.toString(id) + ";")) {
                s = br.readLine();
            } else {
                arquivo.write(s + "\r\n");
                s = br.readLine();
            }
        }
        arquivo.close();

        arquivo = new FileWriter(new File("veiculos.txt"));
        is = new FileInputStream("Arquivo.txt");
        isr = new InputStreamReader(is);
        br = new BufferedReader(isr);
        s = br.readLine();

        while (s != null) {
            arquivo.write(s + "\r\n");
            s = br.readLine();
        }
        arquivo.close();
    }

    public void replace(String s, String edited, int func) throws IOException {
       Path path;
        if(func==0){
            path = FileSystems.getDefault().getPath("veiculos.txt");
        }
        else{
            path = FileSystems.getDefault().getPath("funcionario.txt");
        }
        List<String> fileContent = new ArrayList<>(Files.readAllLines(path, StandardCharsets.UTF_8));

        for (int i = 0; i < fileContent.size(); i++) {
            if (fileContent.get(i).equals(s)) {
                System.out.println(fileContent.get(i));
                fileContent.set(i, edited);
                System.out.println(fileContent.get(i));
                break;
            }
        }

        Files.write(path, fileContent, StandardCharsets.UTF_8);
        
    }
    
    public String findById(int id) throws FileNotFoundException, IOException{
        String result = null;
        InputStream is = new FileInputStream("veiculos.txt");
        InputStreamReader isr = new InputStreamReader(is);
        BufferedReader br = new BufferedReader(isr);
        String s = br.readLine();
      
        while (s != null) {
            if (s.contains("-" + Integer.toString(id) + ";")) {
               result = s;
               return result;
            } else {
                s = br.readLine();
            }
        }
        is.close();
        return result;
    }

}
