package br.com.inatel.squaredeal.model;

import br.com.caelum.stella.boleto.Banco;
import br.com.caelum.stella.boleto.Boleto;
import br.com.caelum.stella.boleto.Datas;
import br.com.caelum.stella.boleto.Emissor;
import br.com.caelum.stella.boleto.Sacado;
import br.com.caelum.stella.boleto.bancos.BancoDoBrasil;
import br.com.caelum.stella.boleto.bancos.Bradesco;
import br.com.caelum.stella.boleto.transformer.GeradorDeBoleto;
import net.sf.jasperreports.engine.JRDataSource;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.collections.ReferenceMap;
import org.apache.commons.digester.Rule;
import com.lowagie.text.DocumentException;
import java.util.Calendar;
import java.util.Date;
import javax.xml.crypto.Data;
import org.apache.commons.beanutils.PropertyUtils;
import net.sourceforge.barbecue.BarcodeException;

public class GerarBoleto {

    public static void main(String[] args) {

        // Para gerar um boleto em PDF
    }

    public void getBoleto(String v, String m) {

        Calendar c = Calendar.getInstance();
        Calendar cv = Calendar.getInstance();
        cv.add(Calendar.DAY_OF_YEAR, 7);

        Datas datas = Datas.novasDatas().comDocumento(c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH), c.get(Calendar.YEAR))
                .comProcessamento(c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH), c.get(Calendar.YEAR))
                .comVencimento(cv.get(Calendar.DAY_OF_MONTH), cv.get(Calendar.MONTH), cv.get(Calendar.YEAR));

        Emissor emissor = Emissor.novoEmissor()
                .comCedente("Square Deal")
                .comAgencia(1824).comDigitoAgencia('4')
                .comContaCorrente(76000)
                .comNumeroConvenio(1207113)
                .comDigitoContaCorrente('5')
                .comCarteira(18)
                .comNossoNumero(9000206);

        Sacado sacado = Sacado.novoSacado()
                .comNome("Guilherme")
                .comCpf("111.222.333-12")
                .comEndereco("Av. João de Camargo, 510")
                .comBairro("Bairro Inatel")
                .comCep("37540-000")
                .comCidade("Santa Rita do Sapucaí")
                .comUf("MG");

        Banco banco = new BancoDoBrasil();

        Boleto boleto = Boleto.novoBoleto()
                .comBanco(banco)
                .comDatas(datas)
                .comDescricoes(m)
                .comEmissor(emissor)
                .comSacado(sacado)
                .comValorBoleto(v)
                .comNumeroDoDocumento("1234")
                .comInstrucoes("")
                .comLocaisDePagamento("local 1", "local 2")
                .comNumeroDoDocumento("4343");

        GeradorDeBoleto gerador = new GeradorDeBoleto(boleto);

        // Para gerar um boleto em PDF
        gerador.geraPDF("Boleto.pdf");

    }
}
