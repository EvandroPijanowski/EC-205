
package br.com.inatel.squaredeal.model;


public class Veiculo 
{
   private String modelo, marca, versao, cor, motor, quilometragem;
   private String anoModelo, anoFabricacao, especie, chassi, valor;

    public String getModelo() { return modelo;}
    public String getMarca() {return marca;}
    public String getVersao() {return versao;}
    public String getCor() {return cor;}
    public String getMotor() {return motor;}
    public String getQuilometragem() {return quilometragem;}
    public String getAnoModelo() {return anoModelo;}
    public String getAnoFabricacao() {return anoFabricacao;}
    public String getEspecie() {return especie;}
    public String getChassi() {return chassi;}
    public String getValor() {return valor;}

    
    
    public void setModelo(String modelo) {this.modelo = modelo;}
    public void setMarca(String marca) {this.marca = marca;}
    public void setVersao(String versao) {this.versao = versao;}
    public void setCor(String cor) {this.cor = cor;}
    public void setMotor(String motor) {this.motor = motor;}
    public void setQuilometragem(String quilometragem) {this.quilometragem = quilometragem;}
    public void setAnoModelo(String anoModelo) {this.anoModelo = anoModelo;}
    public void setAnoFabricacao(String anoFabricacao) {this.anoFabricacao = anoFabricacao;}
    public void setEspecie(String especie) {this.especie = especie;}
    public void setChassi(String chassi) {this.chassi = chassi;}
    public void setValor(String valor) {this.valor = valor;}    
}