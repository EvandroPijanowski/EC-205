package br.com.inatel.squaredeal.view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import br.inatel.squaredeal.controller.Busca;

public class Buscar extends javax.swing.JFrame {

    public Buscar(int adm) {
        admin = adm;
        initComponents();
        setLocationRelativeTo(null);
        setTitle("SquareDeal");
        veiculoButton.setSelected(true);
        setVisible(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        buscarLabel = new javax.swing.JLabel();
        digiteLabel = new javax.swing.JLabel();
        buscaTextField = new javax.swing.JTextField();
        buscar = new javax.swing.JButton();
        voltar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        veiculoButton = new javax.swing.JRadioButton();
        funcionarioButton = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(850, 600));

        buscarLabel.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        buscarLabel.setText("Buscar");

        digiteLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        digiteLabel.setText("Digite uma palavra chave: ");

        buscaTextField.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        buscar.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        buscar.setText("Buscar");
        buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarActionPerformed(evt);
            }
        });

        voltar.setText("Voltar");
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        buttonGroup1.add(veiculoButton);
        veiculoButton.setText("Veiculo");
        veiculoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                veiculoButtonActionPerformed(evt);
            }
        });

        buttonGroup1.add(funcionarioButton);
        funcionarioButton.setText("Funcionario");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(buscarLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(682, 682, 682)
                                .addComponent(voltar, javax.swing.GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(digiteLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 288, Short.MAX_VALUE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(buscaTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addComponent(buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(veiculoButton)
                .addGap(18, 18, 18)
                .addComponent(funcionarioButton)
                .addGap(132, 132, 132))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(buscarLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(digiteLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buscaTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(veiculoButton)
                    .addComponent(funcionarioButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 437, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(voltar, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 621, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarActionPerformed
        String search = buscaTextField.getText();    //salva o que digitou em uma variavel
        String[] aux = new String[12];
        if (veiculoButton.isSelected()) 
        {
            buscaFunc = false;
        } else 
        {
            buscaFunc = true;
        }

        Busca b = new Busca();
        buscaTextField.setText("");
        jTextArea1.selectAll();
        jTextArea1.setText("");
        try {
            resultado = b.busca(search, buscaFunc);
        } catch (IOException ex) {
            Logger.getLogger(Buscar.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (buscaFunc == true) 
        {
            if (resultado == null) 
            {
                JOptionPane.showMessageDialog(null, "Funcionário não encontrado", "Erro", JOptionPane.ERROR_MESSAGE);
            } 
            else 
            {
                for (int i = 0; i < resultado.size(); i++) 
                {
                    aux = resultado.get(i).split("-");
                    jTextArea1.append("Nome:" + aux[0] + " CPF:" + aux[1] + " RG:"
                            + aux[2] + " Salário:R$" + aux[3]);
                    if (aux[4].contains("1")) 
                    {
                        jTextArea1.append(" Administrador\n");
                    } 
                    else 
                    {
                        jTextArea1.append(" Funcionario\n");
                    }
                }
            }
        } 
        else 
            if (resultado == null) 
            {
                JOptionPane.showMessageDialog(null, "Veiculo não encontrado", "Erro", JOptionPane.ERROR_MESSAGE);
            } 
            else 
            {
                for (int i = 0; i < resultado.size(); i++) 
                {
                    aux = resultado.get(i).split("-");
                    jTextArea1.append("Modelo:" + aux[0] + " Marca:" + aux[1] + " Versâo:"
                            + aux[2] + " Cor:" + aux[3] + "\nMotor:" + aux[4] + "Quilometragem:" + aux[5]
                            + " Ano Modelo:" + aux[6] + " Ano Fabricação:" + aux[7] + "\nEspecie:" + aux[8]
                            + " Chassi:" + aux[9] + " Valor:" + aux[10] + "\n\n");
                }
        }
    }//GEN-LAST:event_buscarActionPerformed

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
        // TODO add your handling code here:
        dispose();
        if(admin == 1) new MenuAdministrador();
        else new MenuVendedor();
    }//GEN-LAST:event_voltarActionPerformed

    private void veiculoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_veiculoButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_veiculoButtonActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               
            }
        });
    }
    
    int admin;
    boolean buscaFunc;
    ArrayList<String> resultado;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField buscaTextField;
    private javax.swing.JButton buscar;
    private javax.swing.JLabel buscarLabel;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel digiteLabel;
    private javax.swing.JRadioButton funcionarioButton;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JRadioButton veiculoButton;
    private javax.swing.JButton voltar;
    // End of variables declaration//GEN-END:variables
}
