package br.com.inatel.squaredeal.view;

import br.com.caelum.stella.boleto.Boleto;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import static java.lang.Math.abs;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import br.inatel.squaredeal.controller.Busca;
import br.com.inatel.squaredeal.model.Armazenamento;
import br.com.inatel.squaredeal.model.GerarBoleto;

public class Vender extends javax.swing.JFrame {

    private DefaultListModel lista = new DefaultListModel();
    String[] aux = new String[12];
    int id;

    public Vender(int adm, int e, int f) {
        initComponents();
        setLocationRelativeTo(null);
        buscarButton.addActionListener(new Action());
        setTitle("SquareDeal");
        func = f;
        admin = adm;
        vende = e;
        confirmarButton.setVisible(false);
        if (vende == 0) {
            confirmarButton.setVisible(true);
            confirmarButton.setEnabled(false);
            venderLabel.setText("Editar");
            precoLabel.setVisible(false);
            valorLabel.setVisible(false);
            valorLabel.setVisible(false);
            concluirButton.setText("Editar");
            concluirButton.setEnabled(false);
        }
        setVisible(true);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        buscarButton = new javax.swing.JButton();
        buscarTextField = new javax.swing.JTextField();
        venderLabel = new javax.swing.JLabel();
        buscarLabel = new javax.swing.JLabel();
        precoLabel = new javax.swing.JLabel();
        selecionarButton = new javax.swing.JButton();
        valorLabel = new javax.swing.JLabel();
        confirmarButton = new javax.swing.JButton();
        voltarButton = new javax.swing.JButton();
        concluirButton = new javax.swing.JButton();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setPreferredSize(new java.awt.Dimension(850, 593));

        jList1.setModel(lista);
        jList1.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane1.setViewportView(jList1);
        jScrollPane1.setViewportView(jList1);

        buscarButton.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        buscarButton.setText("Buscar");

        buscarTextField.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        venderLabel.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        venderLabel.setText("Vender");

        buscarLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        buscarLabel.setText("Buscar:");

        precoLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        precoLabel.setText("Preço:");

        selecionarButton.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        selecionarButton.setText("Selecionar");
        selecionarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selecionarButtonActionPerformed(evt);
            }
        });

        confirmarButton.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        confirmarButton.setText("Deletar");
        confirmarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmarButtonActionPerformed(evt);
            }
        });

        voltarButton.setText("Voltar");
        voltarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarButtonActionPerformed(evt);
            }
        });

        concluirButton.setText("Concluir");
        concluirButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                concluirButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(venderLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(buscarLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(31, 31, 31)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 433, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(selecionarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(buscarTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(buscarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(confirmarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(127, 127, 127)
                        .addComponent(concluirButton, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(63, 63, 63)
                        .addComponent(voltarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(precoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(valorLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(148, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(venderLabel)
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(buscarLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buscarTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buscarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addComponent(selecionarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(precoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(valorLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(165, 165, 165)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(voltarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(concluirButton, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(31, 31, 31))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(confirmarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(53, 53, 53))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void selecionarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selecionarButtonActionPerformed
        // TODO add your handling code here:
        if (jList1.isSelectionEmpty()) {
            valorLabel.setText("R$ 0.00");
        } else {
            confirmarButton.setEnabled(true);
            concluirButton.setEnabled(true);
            valorLabel.setText("R$ " + aux[10] + ",00");
        }

    }//GEN-LAST:event_selecionarButtonActionPerformed

    private void confirmarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmarButtonActionPerformed
        // TODO add your handling code here:
        if (func == 0) {
            try {
                String[] nulos = {";"};
                for (String n : nulos) {
                    aux[11] = aux[11].replaceAll(n, "");
                }
                
                id = Integer.parseInt(aux[11].trim());
                Armazenamento a = new Armazenamento();
                
                a.replace(a.findById(id), "", 0);
            } catch (IOException ex) {
                Logger.getLogger(Vender.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {

            try {
                Armazenamento a = new Armazenamento();
                
                s = lista.get(jList1.getSelectedIndex()).toString();
                s = s.replace("Nome:", "");
                s = s.replace(" CPF:", "-");
                s = s.replace(" RG:", "-");
                s = s.replace(" Salário:R$", "-");
                s = s.replace(" Cargo:", "-");
                a.replace(s, "", 1);
            } catch (IOException ex) {
                Logger.getLogger(Vender.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        dispose();
        new MenuAdministrador();


    }//GEN-LAST:event_confirmarButtonActionPerformed

    private void voltarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarButtonActionPerformed
        // TODO add your handling code here:
        dispose();
        if (admin == 1) {
            new MenuAdministrador();
        } else {
            new MenuVendedor();
        }
    }//GEN-LAST:event_voltarButtonActionPerformed

    private void concluirButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_concluirButtonActionPerformed
        // TODO add your handling code here:

        if (valorLabel.getText() == "R$ 0.00") {
            JOptionPane.showMessageDialog(null, "Nenhum veículo foi selecionado!", "Veículo não selecionado", JOptionPane.ERROR_MESSAGE);
        } else if (vende == 1) {
            String[] nulos = {";"};
            for (String n : nulos) {
                aux[11] = aux[11].replaceAll(n, "");
            }

            id = Integer.parseInt(aux[11].trim());
            Armazenamento a = new Armazenamento();
            GerarBoleto g = new GerarBoleto();
            g.getBoleto(aux[10], aux[0]);

            try {
                a.venderVeiculo(id);
                JOptionPane.showMessageDialog(null, "Boleto gerado com sucesso.", "Venda Conluida!", HEIGHT);
                java.awt.Desktop desktop = java.awt.Desktop.getDesktop();

                File arquivoPdf = new File("Boleto.pdf");
                try {
                    desktop.open(arquivoPdf);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                voltarButtonActionPerformed(evt);
            } catch (IOException ex) {
                Logger.getLogger(Vender.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (func == 0) {
            String[] nulos = {";"};
            for (String n : nulos) {
                aux[11] = aux[11].replaceAll(n, "");
            }

            id = Integer.parseInt(aux[11].trim());
            try {
                Armazenamento a = new Armazenamento();

                dispose();
                new CadastrarVeiculo(0, a.findById(id));
            } catch (IOException ex) {
                Logger.getLogger(Vender.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {

            Armazenamento a = new Armazenamento();
            dispose();
            s = lista.get(jList1.getSelectedIndex()).toString();
            s = s.replace("Nome:", "");
            s = s.replace(" CPF:", "-");
            s = s.replace(" RG:", "-");
            s = s.replace(" Salário:R$", "-");
            s = s.replace(" Cargo:", "-");
            
            new CadastrarFuncionario(0, s);
        }
    }//GEN-LAST:event_concluirButtonActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

            }
        });
    }
    String s;
    int func;
    int admin;
    int vende;
    boolean buscaFunc;
    ArrayList<String> resultado;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buscarButton;
    private javax.swing.JLabel buscarLabel;
    private javax.swing.JTextField buscarTextField;
    private javax.swing.JButton concluirButton;
    private javax.swing.JButton confirmarButton;
    private javax.swing.JList<String> jList1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel precoLabel;
    private javax.swing.JButton selecionarButton;
    private javax.swing.JLabel valorLabel;
    private javax.swing.JLabel venderLabel;
    private javax.swing.JButton voltarButton;
    // End of variables declaration//GEN-END:variables

    class Action implements ActionListener {  //Action

        public void actionPerformed(ActionEvent e) {
            String search = buscarTextField.getText();    //salva o que digitou em uma variavel
            Busca b = new Busca();
            buscarTextField.setText("");
            lista.clear();
            if (func == 0) {
                try {
                    resultado = b.busca(search, false);
                } catch (IOException ex) {
                    Logger.getLogger(Buscar.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (resultado == null) {
                    JOptionPane.showMessageDialog(null, "Veiculo não encontrado", "Erro", JOptionPane.ERROR_MESSAGE);
                } else {

                    for (int i = 0; i < resultado.size(); i++) {
                        aux = resultado.get(i).split("-");
                        lista.addElement("Modelo: " + aux[0] + " Marca: " + aux[1] + " Versâo: "
                                + aux[2] + " Cor: " + aux[3] + "\nMotor: " + aux[4] + " Quilometragem: " + aux[5]
                                + " Ano Modelo: " + aux[6] + " Ano Fabricação: " + aux[7] + "\n Especie: " + aux[8]
                                + " Chassi: " + aux[9] + " Valor: " + aux[10] + "\n\n");

                        String[] nulos = {";"};
                        for (String n : nulos) {
                            aux[11] = aux[11].replaceAll(n, "");
                        }
                    }
                    
                }
            } else {
                try {
                    resultado = b.busca(search, true);
                } catch (IOException ex) {
                    Logger.getLogger(Buscar.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (resultado == null) {
                    JOptionPane.showMessageDialog(null, "Funcionário não encontrado", "Erro", JOptionPane.ERROR_MESSAGE);
                } else {

                    for (int i = 0; i < resultado.size(); i++) {
                        aux = resultado.get(i).split("-");
                        lista.addElement("Nome:" + aux[0] + " CPF:" + aux[1] + " RG:"
                                + aux[2] + " Salário:R$" + aux[3] + " Cargo:" + aux[4]);

                    }
                }

            }
        }
    }

}
