
package br.inatel.squaredeal.controller;

import br.com.inatel.squaredeal.view.Login;

/**
 *
 * @author C I C E R O
 */
public class SquareDeal 
{

    
    public static void main(String[] args) 
    {
        Login l = new Login();
    }
}
