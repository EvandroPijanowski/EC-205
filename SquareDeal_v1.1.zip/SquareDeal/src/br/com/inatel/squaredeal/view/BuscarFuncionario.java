
package br.com.inatel.squaredeal.view;

import br.com.inatel.squaredeal.view.MenuVendedor;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import br.inatel.squaredeal.controller.Busca;
import java.util.ArrayList;
import javax.swing.DefaultListModel;


public class BuscarFuncionario extends javax.swing.JFrame {

    //private DefaultListModel lista = new DefaultListModel();
    public BuscarFuncionario() 
    {
        initComponents();
        setTitle("SquareDeal");
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        corLabel = new javax.swing.JLabel();
        airbagLabel = new javax.swing.JLabel();
        portasLabel = new javax.swing.JLabel();
        marcaLabel = new javax.swing.JLabel();
        modeloLabel = new javax.swing.JLabel();
        corTextField = new javax.swing.JTextField();
        marcaTextField = new javax.swing.JTextField();
        modeloTextField = new javax.swing.JTextField();
        pesquisarButton = new javax.swing.JButton();
        simRB = new javax.swing.JRadioButton();
        naoRB = new javax.swing.JRadioButton();
        zeroRB = new javax.swing.JRadioButton();
        doisRB = new javax.swing.JRadioButton();
        quatroRB = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        voltarButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        corLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        corLabel.setText("Cor:");

        airbagLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        airbagLabel.setText("Airbag:");

        portasLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        portasLabel.setText("Portas:");

        marcaLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        marcaLabel.setText("Marca:");

        modeloLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        modeloLabel.setText("Modelo: ");

        corTextField.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        marcaTextField.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        modeloTextField.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        modeloTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modeloTextFieldActionPerformed(evt);
            }
        });

        pesquisarButton.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        pesquisarButton.setText("Pesquisar");
        pesquisarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pesquisarButtonActionPerformed(evt);
            }
        });

        buttonGroup1.add(simRB);
        simRB.setFont(new java.awt.Font("Century", 0, 14)); // NOI18N
        simRB.setText("Sim");
        simRB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simRBActionPerformed(evt);
            }
        });

        buttonGroup1.add(naoRB);
        naoRB.setFont(new java.awt.Font("Century", 0, 14)); // NOI18N
        naoRB.setText("Não");

        buttonGroup2.add(zeroRB);
        zeroRB.setFont(new java.awt.Font("Century", 0, 14)); // NOI18N
        zeroRB.setText("0");

        buttonGroup2.add(doisRB);
        doisRB.setFont(new java.awt.Font("Century", 0, 14)); // NOI18N
        doisRB.setText("2");

        buttonGroup2.add(quatroRB);
        quatroRB.setFont(new java.awt.Font("Century", 0, 14)); // NOI18N
        quatroRB.setText("4");

        jLabel1.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        jLabel1.setText("Buscar");

        voltarButton.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        voltarButton.setText("Voltar");
        voltarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarButtonActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(314, 314, 314)
                .addComponent(pesquisarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(voltarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(portasLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(airbagLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(naoRB)
                            .addComponent(simRB)
                            .addComponent(doisRB)
                            .addComponent(zeroRB)
                            .addComponent(quatroRB)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(corLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(corTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(marcaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(marcaTextField))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(modeloLabel)
                        .addGap(10, 10, 10)
                        .addComponent(modeloTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(148, 148, 148)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 563, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(43, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(corLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(corTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(airbagLabel)
                    .addComponent(simRB))
                .addGap(4, 4, 4)
                .addComponent(naoRB)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(portasLabel)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(zeroRB)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(doisRB)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(quatroRB)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(marcaLabel)
                    .addComponent(marcaTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(modeloLabel)
                    .addComponent(modeloTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(118, 118, 118))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(103, 103, 103)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 411, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(pesquisarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(voltarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void modeloTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modeloTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_modeloTextFieldActionPerformed

    private void pesquisarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pesquisarButtonActionPerformed

        String cor, airbag, portas, marca, modelo;
        Busca b = new Busca();
        
        cor = corTextField.getText();
        marca = marcaTextField.getText();
        modelo = modeloTextField.getText();
        if(simRB.isSelected())
            airbag = "Sim";
        else
            airbag = "Não";
        if(zeroRB.isSelected())
            portas = "0";
        else
            if(doisRB.isSelected())
                portas = "2";
        else
                portas = "4";
        try 
        {

            
            jTextArea1.setText(" ");
            InputStream is = new FileInputStream("veiculos.txt");
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            String line;
            String[] aux;
            while ((line = br.readLine()) != null) 
            {
                if ((line.contains(cor)) && (line.contains(airbag)) && (line.contains(portas)) && (line.contains(marca)) && (line.contains(modelo))) 
                {
                    aux = line.split("-");
                    jTextArea1.append("Modelo:" + aux[0] + " Marca:" + aux[1] + " Versão:"
                            + aux[2] + " Cor:" + aux[3] + "\nMotor:" + aux[4] + " Quilometragem:" + aux[5]
                            + " Ano Modelo:" + aux[6] + " Ano Fabricação:" + aux[7] + "\nEspecie:" + aux[8]
                            + " Chassi:" + aux[9] + " Valor:" + aux[10] + " Airbag: " + aux[11] + "\nQuantidade de portas: " + aux[12] + "\n\n");
                }
            }
            jTextArea1.setEditable(false);
            if(" ".equals(jTextArea1.getText()))
                JOptionPane.showMessageDialog(null, "Veiculo não encontrado", "Erro", JOptionPane.ERROR_MESSAGE);
            
        } catch (IOException ex) {
            Logger.getLogger(BuscarFuncionario.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_pesquisarButtonActionPerformed

    private void simRBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simRBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_simRBActionPerformed

    private void voltarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarButtonActionPerformed
        // TODO add your handling code here:
        dispose();
        new MenuVendedor();
    }//GEN-LAST:event_voltarButtonActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BuscarFuncionario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel airbagLabel;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JLabel corLabel;
    private javax.swing.JTextField corTextField;
    private javax.swing.JRadioButton doisRB;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel marcaLabel;
    private javax.swing.JTextField marcaTextField;
    private javax.swing.JLabel modeloLabel;
    private javax.swing.JTextField modeloTextField;
    private javax.swing.JRadioButton naoRB;
    private javax.swing.JButton pesquisarButton;
    private javax.swing.JLabel portasLabel;
    private javax.swing.JRadioButton quatroRB;
    private javax.swing.JRadioButton simRB;
    private javax.swing.JButton voltarButton;
    private javax.swing.JRadioButton zeroRB;
    // End of variables declaration//GEN-END:variables
}
