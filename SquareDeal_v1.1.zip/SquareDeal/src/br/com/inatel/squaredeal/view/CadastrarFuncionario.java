package br.com.inatel.squaredeal.view;

import br.com.inatel.squaredeal.model.Funcionario;
import br.com.inatel.squaredeal.model.Armazenamento;
import br.com.inatel.squaredeal.model.Validacao;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JOptionPane;


public class CadastrarFuncionario extends javax.swing.JFrame {

    Armazenamento a = new Armazenamento();

    public CadastrarFuncionario(int c, String s) {
        initComponents();
        cadastra = c;
        str = s;
        if (cadastra == 0) {
            cadastroLabel.setText("Editar Funcionário");
            textLogin.setVisible(false);
            textSenha.setVisible(false);
            jLabel1.setVisible(false);
            jLabel2.setVisible(false);
            edit();
        }
        setLocationRelativeTo(null);
        setVisible(true);
        setTitle("SquareDeal");
        funcionarioButton.setSelected(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        cadastroLabel = new javax.swing.JLabel();
        nomeLabel = new javax.swing.JLabel();
        textNome = new javax.swing.JTextField();
        cpfLabel = new javax.swing.JLabel();
        textCpf = new javax.swing.JTextField();
        rgLabel = new javax.swing.JLabel();
        textRg = new javax.swing.JTextField();
        cargoLabel = new javax.swing.JLabel();
        salarioLabel = new javax.swing.JLabel();
        textSalario = new javax.swing.JTextField();
        Salvar = new javax.swing.JButton();
        admButton = new javax.swing.JRadioButton();
        funcionarioButton = new javax.swing.JRadioButton();
        voltarButton = new javax.swing.JButton();
        textLogin = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        textSenha = new javax.swing.JTextField();
        logoLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        cadastroLabel.setFont(new java.awt.Font("Copperplate Gothic Bold", 1, 40)); // NOI18N
        cadastroLabel.setText("Cadastrar Funcionários");

        nomeLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        nomeLabel.setText("Nome:");
        nomeLabel.setName("Nome"); // NOI18N

        textNome.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        textNome.setName("textNome"); // NOI18N
        textNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNomeActionPerformed(evt);
            }
        });

        cpfLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        cpfLabel.setText("CPF: ");

        textCpf.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        rgLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        rgLabel.setText("RG:");

        textRg.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        cargoLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        cargoLabel.setText("Cargo:");

        salarioLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        salarioLabel.setText("Salário:");

        textSalario.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        Salvar.setBackground(new java.awt.Color(255, 255, 255));
        Salvar.setFont(new java.awt.Font("Century", 0, 24)); // NOI18N
        Salvar.setForeground(new java.awt.Color(0, 0, 255));
        Salvar.setText("Salvar");
        Salvar.setName("Salvar"); // NOI18N
        Salvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalvarActionPerformed(evt);
            }
        });

        buttonGroup1.add(admButton);
        admButton.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        admButton.setText("Administrador");

        buttonGroup1.add(funcionarioButton);
        funcionarioButton.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        funcionarioButton.setText("Funcionário");

        voltarButton.setBackground(new java.awt.Color(255, 255, 255));
        voltarButton.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        voltarButton.setForeground(new java.awt.Color(255, 0, 0));
        voltarButton.setText("Voltar");
        voltarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarButtonActionPerformed(evt);
            }
        });

        textLogin.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel1.setText("Usuário");

        jLabel2.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel2.setText("Senha");

        textSenha.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        logoLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/inatel/squaredeal/view/logo.jpg"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(cargoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(admButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(funcionarioButton))
                    .addComponent(jLabel1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cadastroLabel)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Salvar, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rgLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(nomeLabel)
                                    .addComponent(cpfLabel)
                                    .addComponent(salarioLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(30, 30, 30)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(textCpf, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
                                    .addComponent(textNome)
                                    .addComponent(textRg)
                                    .addComponent(textSalario)
                                    .addComponent(textLogin)
                                    .addComponent(textSenha))))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 89, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(logoLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(voltarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cadastroLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(logoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nomeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textCpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cpfLabel))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rgLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textRg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                                .addComponent(textSalario))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(salarioLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textLogin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(textSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(38, 38, 38)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cargoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(admButton)
                            .addComponent(funcionarioButton))
                        .addGap(32, 32, 32)
                        .addComponent(Salvar, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(23, Short.MAX_VALUE))
                    .addComponent(voltarButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void textNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNomeActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_textNomeActionPerformed

    private void SalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalvarActionPerformed

        if (ColetaDados()) {
            JOptionPane.showMessageDialog(null, "As informações foram salvas corretamente.", "Dados salvos", JOptionPane.WARNING_MESSAGE);
            voltar();
        }
    }//GEN-LAST:event_SalvarActionPerformed

    private void voltarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarButtonActionPerformed
        // TODO add your handling code here:
        voltar();
    }//GEN-LAST:event_voltarButtonActionPerformed

    private void voltar() {
        dispose();
        new MenuAdministrador();
    }

    public boolean ColetaDados() {
        Funcionario funcionario = new Funcionario();
        Armazenamento a = new Armazenamento();
        Validacao v = new Validacao();
        String nome, cpf, rg, salario, user, password;

        nome = textNome.getText();
        cpf = textCpf.getText();
        rg = textRg.getText();
        salario = textSalario.getText();
        user = textLogin.getText();
        password = textSenha.getText();

        if (!Validacao.isValidNome(nome)) {
            JOptionPane.showMessageDialog(null, "O nome não pode conter caracteres especias ou números", "Erro no nome inserido", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!Validacao.isValidCpf(cpf)) {
            JOptionPane.showMessageDialog(null, "O CPF só pode conter 11 números ", "Erro no CPF inserido", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!Validacao.isValidRg(rg)) {
            JOptionPane.showMessageDialog(null, "O RG não pode conter caracteres especias ou letras.", "Erro no RG inserido", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!Validacao.isSalario(salario)) {
            JOptionPane.showMessageDialog(null, "O salário só pode conter números", "Erro no salário inserido", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        funcionario.setNome(textNome.getText());
        funcionario.setCpf(textCpf.getText());
        funcionario.setRg(textRg.getText());
        funcionario.setSalario(textSalario.getText());
        if (admButton.isSelected()) {
            funcionario.setCargo(1);
        } else {
            funcionario.setCargo(0);
        }

        try {
            if (cadastra == 1) {
                a.salvarUser(user, password, funcionario.getCargo());
                a.salvaFuncionario(nome, cpf, rg, salario, funcionario.getCargo());
            } else {
                str = nome + "-" + cpf + "-" + rg + "-" + salario + "-" + funcionario.getCargo();
                a.replace(strin, str, 1);
            }
        } catch (IOException ex) {
            Logger.getLogger(CadastrarFuncionario.class.getName()).log(Level.SEVERE, null, ex);
        }

        return true;

    }

    public void edit() {
        strin = str;
        aux = str.split("-");
        System.out.println(strin);
        textNome.setText(aux[0]);
        textCpf.setText(aux[1]);
        textRg.setText(aux[2]);
        textSalario.setText(aux[3]);
        if (aux[4].equalsIgnoreCase("1")) {
            admButton.isSelected();
        } else {
            funcionarioButton.isSelected();
        }

    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CadastrarFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CadastrarFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CadastrarFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CadastrarFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                //new CadastrarFuncionario().setVisible(true);
            }
        });
    }

    String[] aux = new String[4];
    String strin;
    String str;
    int cadastra;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Salvar;
    private javax.swing.JRadioButton admButton;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel cadastroLabel;
    private javax.swing.JLabel cargoLabel;
    private javax.swing.JLabel cpfLabel;
    private javax.swing.JRadioButton funcionarioButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel logoLabel;
    private javax.swing.JLabel nomeLabel;
    private javax.swing.JLabel rgLabel;
    private javax.swing.JLabel salarioLabel;
    private javax.swing.JTextField textCpf;
    private javax.swing.JTextField textLogin;
    private javax.swing.JTextField textNome;
    private javax.swing.JTextField textRg;
    private javax.swing.JTextField textSalario;
    private javax.swing.JTextField textSenha;
    private javax.swing.JButton voltarButton;
    // End of variables declaration//GEN-END:variables
}
