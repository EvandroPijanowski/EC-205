package br.com.inatel.squaredeal.view;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import br.com.inatel.squaredeal.model.Armazenamento;
import br.com.inatel.squaredeal.model.Veiculo;

public class CadastrarVeiculo extends javax.swing.JFrame {

    Armazenamento a = new Armazenamento();

    public CadastrarVeiculo(int c, String s) {
        initComponents();
        cadastra = c;
        str = s;
        setLocationRelativeTo(null);
        if (cadastra == 0) {
            cadastrarLabel.setText("Editar Veiculo");
            edit();
        }

        setTitle("SquareDeal");
        setVisible(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        cadastrarLabel = new javax.swing.JLabel();
        marcaLabel = new javax.swing.JLabel();
        modeloLabel = new javax.swing.JLabel();
        anoLabel = new javax.swing.JLabel();
        corLabel = new javax.swing.JLabel();
        motorLabel = new javax.swing.JLabel();
        quilometragemLabel = new javax.swing.JLabel();
        versaoLabel = new javax.swing.JLabel();
        chassiLabel = new javax.swing.JLabel();
        anoModeloLabel = new javax.swing.JLabel();
        especieLabel = new javax.swing.JLabel();
        marcaText = new javax.swing.JTextField();
        modeloText = new javax.swing.JTextField();
        versaoText = new javax.swing.JTextField();
        corText = new javax.swing.JTextField();
        motorText = new javax.swing.JTextField();
        quilometragemText = new javax.swing.JTextField();
        fabricacaoText = new javax.swing.JTextField();
        anoModeloText = new javax.swing.JTextField();
        especieText = new javax.swing.JTextField();
        chassiText = new javax.swing.JTextField();
        salvar = new javax.swing.JButton();
        valorLabel = new javax.swing.JLabel();
        valorText = new javax.swing.JTextField();
        voltarButton = new javax.swing.JButton();
        logoLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        cadastrarLabel.setFont(new java.awt.Font("Copperplate Gothic Bold", 1, 48)); // NOI18N
        cadastrarLabel.setText("Cadastrar Veículo");

        marcaLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        marcaLabel.setText("Marca:");

        modeloLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        modeloLabel.setText("Modelo:");

        anoLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        anoLabel.setText("Ano de fabricação:");

        corLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        corLabel.setText("Cor:");

        motorLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        motorLabel.setText("Motor: ");

        quilometragemLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        quilometragemLabel.setText("Quilometragem: ");

        versaoLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        versaoLabel.setText("Versão:");

        chassiLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        chassiLabel.setText("Número do Chassi:");

        anoModeloLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        anoModeloLabel.setText("Ano do Modelo:");

        especieLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        especieLabel.setText("Espécie:");

        marcaText.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        modeloText.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        versaoText.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        corText.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        motorText.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        quilometragemText.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        fabricacaoText.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        anoModeloText.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        especieText.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        chassiText.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        salvar.setBackground(new java.awt.Color(255, 255, 255));
        salvar.setFont(new java.awt.Font("Century", 0, 24)); // NOI18N
        salvar.setText("Salvar");
        salvar.setActionCommand("");
        salvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salvarActionPerformed(evt);
            }
        });

        valorLabel.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        valorLabel.setText("Valor:");

        valorText.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N

        voltarButton.setBackground(new java.awt.Color(255, 255, 255));
        voltarButton.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        voltarButton.setForeground(new java.awt.Color(255, 0, 0));
        voltarButton.setText("Voltar");
        voltarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarButtonActionPerformed(evt);
            }
        });

        logoLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/inatel/squaredeal/view/logo.jpg"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(cadastrarLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addComponent(logoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(salvar, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(valorLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(marcaLabel)
                            .addComponent(modeloLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(anoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(corLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(quilometragemLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(chassiLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(versaoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(anoModeloLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(especieLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(motorLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(68, 68, 68)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(marcaText, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                            .addComponent(modeloText, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                            .addComponent(versaoText, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                            .addComponent(corText, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                            .addComponent(motorText, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                            .addComponent(quilometragemText, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                            .addComponent(fabricacaoText, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                            .addComponent(anoModeloText, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                            .addComponent(especieText, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                            .addComponent(chassiText, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                            .addComponent(valorText, javax.swing.GroupLayout.Alignment.LEADING))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(voltarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(logoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(cadastrarLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(marcaLabel)
                    .addComponent(marcaText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(modeloLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(modeloText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(versaoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(versaoText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(corLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(corText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(motorLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(motorText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quilometragemLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quilometragemText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(anoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(fabricacaoText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(anoModeloLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(anoModeloText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(especieLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(especieText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chassiLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(chassiText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(valorLabel)
                    .addComponent(valorText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(58, 58, 58)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(salvar, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(voltarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(33, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void salvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salvarActionPerformed
        // TODO add your handling code here:

        if (Cadastrar() == false) {
            JOptionPane.showMessageDialog(null, "Algum dado não foi digitado corretamente", "Dados incorretos", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "As informações foram salvas corretamente.", "Dados salvos", JOptionPane.WARNING_MESSAGE);
            voltar();
        }
    }//GEN-LAST:event_salvarActionPerformed

    private void voltarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarButtonActionPerformed
        // TODO add your handling code here:
        voltar();
    }//GEN-LAST:event_voltarButtonActionPerformed

    private void voltar() {
        dispose();
        new MenuAdministrador();
    }

    boolean Cadastrar() {
        Veiculo v = new Veiculo();

        if (marcaText.getText().isEmpty() || modeloText.getText().isEmpty() || versaoText.getText().isEmpty()
                || corText.getText().isEmpty() || motorText.getText().isEmpty() || quilometragemText.getText().isEmpty()
                || fabricacaoText.getText().isEmpty() || anoModeloText.getText().isEmpty() || especieText.getText().isEmpty()
                || chassiText.getText().isEmpty() || valorText.getText().isEmpty()) {

            return false;
        }

        v.setMarca(marcaText.getText());
        v.setModelo(modeloText.getText());
        v.setVersao(versaoText.getText());
        v.setCor(corText.getText());
        v.setMotor(motorText.getText());
        v.setQuilometragem(quilometragemText.getText());
        v.setAnoFabricacao(fabricacaoText.getText());
        v.setAnoModelo(anoModeloText.getText());
        v.setEspecie(especieText.getText());
        v.setChassi(chassiText.getText());
        v.setValor(valorText.getText());

        try {
            if(cadastra == 1){
                a.salvarVeiculo(v);
            }else{
                str = v.getModelo() + "-" + v.getMarca() + "-" + v.getVersao() + "-" + v.getCor()
                + "-" + v.getMotor() + "-" + v.getQuilometragem() + "-" + v.getAnoModelo() + "-"
                + v.getAnoFabricacao() + "-" + v.getEspecie() + "-" + v.getChassi() + "-" + v.getValor() + "-" + aux[11] + ";";
                a.replace(strin, str,0);
            }
        } catch (IOException ex) {
            Logger.getLogger(CadastrarVeiculo.class.getName()).log(Level.SEVERE, null, ex);
        }

        return true;
    }

    public void edit() {
        strin = str;
        aux = str.split("-");
        marcaText.setText(aux[0]);
        modeloText.setText(aux[1]);
        versaoText.setText(aux[2]);
        corText.setText(aux[3]);
        motorText.setText(aux[4]);
        quilometragemText.setText(aux[5]);
        fabricacaoText.setText(aux[6]);
        anoModeloText.setText(aux[7]);
        especieText.setText(aux[8]);
        chassiText.setText(aux[9]);
        valorText.setText(aux[10]);
        

    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            }
        });
    }
    
    String[] aux = new String[12];
    String strin;
    String str;
    int cadastra;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel anoLabel;
    private javax.swing.JLabel anoModeloLabel;
    private javax.swing.JTextField anoModeloText;
    private javax.swing.JLabel cadastrarLabel;
    private javax.swing.JLabel chassiLabel;
    private javax.swing.JTextField chassiText;
    private javax.swing.JLabel corLabel;
    private javax.swing.JTextField corText;
    private javax.swing.JLabel especieLabel;
    private javax.swing.JTextField especieText;
    private javax.swing.JTextField fabricacaoText;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel logoLabel;
    private javax.swing.JLabel marcaLabel;
    private javax.swing.JTextField marcaText;
    private javax.swing.JLabel modeloLabel;
    private javax.swing.JTextField modeloText;
    private javax.swing.JLabel motorLabel;
    private javax.swing.JTextField motorText;
    private javax.swing.JLabel quilometragemLabel;
    private javax.swing.JTextField quilometragemText;
    private javax.swing.JButton salvar;
    private javax.swing.JLabel valorLabel;
    private javax.swing.JTextField valorText;
    private javax.swing.JLabel versaoLabel;
    private javax.swing.JTextField versaoText;
    private javax.swing.JButton voltarButton;
    // End of variables declaration//GEN-END:variables
}
